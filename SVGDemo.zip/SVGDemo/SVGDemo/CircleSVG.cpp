#include "CircleSVG.h"
#include "stdafx.h"
#include "SVGDemo.h"

void Circle::readLine(const string& line) {
    string line1 = removeSpacesBetweenQuotes(line);
    istringstream iss(line1);
    string token;
    while (iss >> token) {
        size_t equalPos = token.find('=');
        if (equalPos != string::npos) {
            string key = token.substr(0, equalPos);
            string value = token.substr(equalPos + 2, token.size() - equalPos - 3);
            if (key == "cx") {
                cx = stod(value);
            }
            else if (key == "cy") {
                cy = stod(value);
            }
            else if (key == "r") {
                r = stod(value);
            }
            else if (key == "fill") {
                fill = value;
            }
            else if (key == "stroke") {
                stroke = value;
            }
            else if (key == "stroke-width") {
                strokeWidth = stoi(value);
            }
            else if (key == "stroke-opacity") {
                strokeOpacity = stof(value);
            }
            else if (key == "fill-opacity") {
                fillOpacity = stof(value);
            }
        }
    }
}
void Circle::drawCircle(HDC hdc) {
    Graphics graphics(hdc);
    Pen pen(Color(0, 0, 0, 0));
    RectF ellipseRect(cx, cy, r, r);
    graphics.DrawEllipse(&pen, ellipseRect);
}