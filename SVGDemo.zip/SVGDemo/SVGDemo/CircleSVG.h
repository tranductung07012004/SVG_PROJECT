#pragma once
#include "FunctionRead.h"
#include "stdafx.h"

class Circle {
private:
    float fillOpacity = 0;
    float strokeOpacity = 0;
    string fill = "";
    string stroke = "";
    int strokeWidth = 0;
    double cx = 0;
    double cy = 0;
    double r = 0;
    string transform = "";
public:
    void readLine(const string& line);
    void drawCircle(HDC);
};