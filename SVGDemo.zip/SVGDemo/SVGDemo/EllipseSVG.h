#pragma once
#include "FunctionRead.h"
#include "stdafx.h"

class Ellipse1 {
private:
    float fillOpacity = 0;
    float strokeOpacity = 0;
    string fill = "";
    string stroke = "";
    int strokeWidth = 0;
    double cx = 0;
    double cy = 0;
    double rx = 0, ry = 0;
    string transform = "";
public:
    void readLine(const string& line);
    void drawEllipse(HDC);
};