#pragma once
#include <iostream>
#include <string>
#include <fstream>
#include <sstream>
#include <vector>
#include "stdafx.h"
using namespace std;

struct PointS {
	int x, y;
};

string removeSpacesBetweenQuotes(const string& input);
string extractPointsValue(string& input);