#pragma once
#include "FunctionRead.h"
#include "stdafx.h"

class Polygon1 {
private:
    float fillOpacity = 0;
    float strokeOpacity = 0;
    string fill = "";
    string stroke = "";
    int strokeWidth = 0;
    vector<PointF> points;
public:
    void readLine(const string& line);
    void drawPolygon(HDC);
};