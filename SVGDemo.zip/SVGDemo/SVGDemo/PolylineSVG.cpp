#include "PolylineSVG.h"
#include "SVGDemo.h"

void Polyline1::readLine(const string& line) {
    string tmp = line;
    string linepoint = extractPointsValue(tmp);
    string line1 = removeSpacesBetweenQuotes(tmp);
    istringstream iss(line1);
    string token;

    while (iss >> token) {
        size_t equalPos = token.find('=');
        if (equalPos != string::npos) {
            string key = token.substr(0, equalPos);
            string value = token.substr(equalPos + 2, token.size() - equalPos - 3);
            if (key == "fill") {
                fill = value;
            }
            else if (key == "fill-opacity") {
                fillOpacity = stof(value);
            }
            else if (key == "stroke") {
                stroke = value;
            }
            else if (key == "stroke-opacity") {
                strokeOpacity = stof(value);
            }
            else if (key == "stroke-width") {
                strokeWidth = stoi(value);
            }

        }
    }
    istringstream in(linepoint);
    string token1;

    while (getline(in, token1, ' ')) {
        PointF p;
        istringstream pointStream(token1);
        char comma;
        pointStream >> p.X >> comma >> p.Y;
        points.push_back(p);
    }
}

void Polyline1::drawPolyline(HDC hdc) {
    Graphics graphics(hdc);
    Pen pen(Color(0, 0, 0, 0));
    PointF* point = new PointF[points.size()];
    for (int i = 0; i < points.size(); i++) {
        point[i] = points[i];
    }
    graphics.DrawLines(&pen, point, points.size());
}