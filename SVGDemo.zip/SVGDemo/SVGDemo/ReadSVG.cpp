#include "ReadSVG.h"

void Readfile() {
    string filePath = "sample.svg";
    fstream file(filePath);
    if (!file.is_open()) {
        cerr << "Failed to open the file." << endl;
    }

    string line;
    while (getline(file, line)) {
        if (line.find("<line") != string::npos) {
            Line myLine;
            myLine.readLine(line);
            cout << endl;
        }
        else if (line.find("<polygon") != string::npos) {
            Polygon1 myPolygon;
            myPolygon.readLine(line);
            cout << endl;
        }
        else if (line.find("<rect") != string::npos) {
            Rect1 myRect;
            myRect.readLine(line);
            cout << endl;
        }
        else if (line.find("<circle") != string::npos) {
            Circle myCircle;
            myCircle.readLine(line);
            cout << endl;

        }
        else if (line.find("<ellipse") != string::npos) {
            Ellipse1 myEllipse;
            myEllipse.readLine(line);
        }
        else if (line.find("<polyline") != string::npos) {
            Polyline1 myPolyline;
            myPolyline.readLine(line);
            cout << endl;
        }
        else if (line.find("<text") != string::npos) {
            Text myText;
            myText.readLine(line);
            cout << endl;
        }
    }
    file.close();
}