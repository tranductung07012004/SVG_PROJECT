#include "stdafx.h"
#include "ReadSVG.h"


vector<SVGElement> parseSVG(const string& filename) {
    vector<SVGElement> elements;

    ifstream file(filename);
    if (!file) {
        cerr << "Failed to open the SVG file." << endl;
        return elements;
    }

    // Read the content of the SVG file into a string
    string xmlContent;
    string line;
    while (getline(file, line)) {
        xmlContent += line + ' ';
    }

    // Parse the XML content using RapidXML
    xml_document<> doc;
    doc.parse<0>(&xmlContent[0]);

    // Traverse the XML document and extract data from different SVG elements
    xml_node<>* svgNode = doc.first_node("svg");
    if (svgNode) {
        for (xml_node<>* node = svgNode->first_node(); node; node = node->next_sibling()) {
            SVGElement element;
            element.type = node->name();

            for (xml_attribute<>* attr = node->first_attribute(); attr; attr = attr->next_attribute()) {
                element.attributes[attr->name()] = attr->value();
            }

            // Check if the element is of type "text" and extract its content
            if (element.type == "text") {
                element.textContent = node->value();
            }
            elements.push_back(element);
        }
    }

    file.close();
    return elements;
}


void printSVGElements(const vector<SVGElement>& elements) {
    for (const SVGElement& element : elements) {
        cout << "Element type: " << element.type << endl;
        cout << "Attributes:" << endl;

        for (const auto& attribute : element.attributes) {
            cout << attribute.first << " = " << attribute.second << endl;
        }

        if (!element.textContent.empty()) {
            cout << "Text Content: " << element.textContent << endl;
        }

        cout << "-----------------------------" << endl;
    }
}


RGBSVG colorSVG(const string& s) {
    RGBSVG color;

    // Regular expression pattern to match the RGB values
    regex pattern("rgb\\((\\d+),\\s*(\\d+),\\s*(\\d+)\\)");
    smatch match;

    if (regex_search(s, match, pattern) && match.size() == 4) {
        color.R = stod(match[1].str());
        color.G = stod(match[2].str());
        color.B = stod(match[3].str());
    }
    return color;
}

vector<PointSVG> parsePointString(const string& input) {
    vector<PointSVG> points;
    istringstream ss(input);
    string token;

    while (getline(ss, token, ' ')) {
        PointSVG point;
        size_t commaPos = token.find(',');
        if (commaPos != string::npos) {
            point.x = stod(token.substr(0, commaPos));
            point.y = stod(token.substr(commaPos + 1));
            points.push_back(point);
        }
    }
    return points;
}

void RectSVG::parseShapeSVG(const SVGElement& element) {
    for (const auto& attr : element.attributes) {
        if (attr.first == "x") {
            x = stod(attr.second);
        }
        else if (attr.first == "y") {
            y = stod(attr.second);
        }
        else if (attr.first == "width") {
            width = stod(attr.second);
        }
        else if (attr.first == "height") {
            height = stod(attr.second);
        }
        else if (attr.first == "rx") {
            rx = stod(attr.second);
        }
        else if (attr.first == "ry") {
            ry = stod(attr.second);
        }
        else if (attr.first == "fill") {
            fill = colorSVG(attr.second);
        }
        else if (attr.first == "fill-opacity") {
            fillOpacity = stod(attr.second);
        }
        else if (attr.first == "stroke") {
            stroke = colorSVG(attr.second);
        }
        else if (attr.first == "stroke-opacity") {
            strokeOpacity = stod(attr.second);
        }
        else if (attr.first == "stroke-width") {
            strokeWidth = stod(attr.second);
        }
        else if (attr.first == "transform") {
            transform = attr.second;
        }
        else if (attr.first == "style") {
            style = attr.second;
        }
    }
}

void TextSVG::parseShapeSVG(const SVGElement& element) {
    for (const auto& attr : element.attributes) {
        if (attr.first == "x") {
            x = stod(attr.second);
        }
        else if (attr.first == "y") {
            y = stod(attr.second);
        }
        else if (attr.first == "font-size") {
            fontSize = stod(attr.second);
        }
        else if (attr.first == "font-weight") {
            fontWeight = stod(attr.second);
        }
        else if (attr.first == "font-style") {
            fontStyle = attr.second;
        }
        else if (attr.first == "font-family") {
            fontFamily = attr.second;
        }
        else if (attr.first == "text-anchor") {
            textAnchor = attr.second;
        }
        else if (attr.first == "text-decoration") {
            textDecoration = attr.second;
        }
        else if (attr.first == "text-transform") {
            textTransform = attr.second;
        }
        else if (attr.first == "fill") {
            fill = colorSVG(attr.second);
        }
        else if (attr.first == "fill-opacity") {
            fillOpacity = stod(attr.second);
        }
        else if (attr.first == "stroke") {
            stroke = colorSVG(attr.second);
        }
        else if (attr.first == "stroke-opacity") {
            strokeOpacity = stod(attr.second);
        }
        else if (attr.first == "stroke-width") {
            strokeWidth = stod(attr.second);
        }
    }

    // Store the text content from the SVG element
    textContent = element.textContent;
}

void CircleSVG::parseShapeSVG(const SVGElement& element) {
    for (const auto& attr : element.attributes) {
        if (attr.first == "stroke-width") {
            strokeWidth = stod(attr.second);
        }
        else if (attr.first == "cx") {
            cx = stod(attr.second);
        }
        else if (attr.first == "cy") {
            cy = stod(attr.second);
        }
        else if (attr.first == "r") {
            r = stod(attr.second);
        }
        else if (attr.first == "fill") {
            fill = colorSVG(attr.second);
        }
        else if (attr.first == "fill-opacity") {
            fillOpacity = stod(attr.second);
        }
        else if (attr.first == "stroke") {
            stroke = colorSVG(attr.second);
        }
        else if (attr.first == "stroke-opacity") {
            strokeOpacity = stod(attr.second);
        }
        else if (attr.first == "transform") {
            transform = attr.second;
        }
        else if (attr.first == "style") {
            style = attr.second;
        }
    }
}

void EllipseSVG::parseShapeSVG(const SVGElement& element) {
    for (const auto& attr : element.attributes) {
        if (attr.first == "cx") {
            cx = stod(attr.second);
        }
        else if (attr.first == "cy") {
            cy = stod(attr.second);
        }
        else if (attr.first == "rx") {
            rx = stod(attr.second);
        }
        else if (attr.first == "ry") {
            ry = stod(attr.second);
        }
        else if (attr.first == "fill") {
            fill = colorSVG(attr.second);
        }
        else if (attr.first == "fill-opacity") {
            fillOpacity = stod(attr.second);
        }
        else if (attr.first == "stroke") {
            stroke = colorSVG(attr.second);
        }
        else if (attr.first == "stroke-opacity") {
            strokeOpacity = stod(attr.second);
        }
        else if (attr.first == "stroke-width") {
            strokeWidth = stod(attr.second);
        }
        else if (attr.first == "transform") {
            transform = attr.second;
        }
        else if (attr.first == "style") {
            style = attr.second;
        }
    }
}

void LineSVG::parseShapeSVG(const SVGElement& element) {
    for (const auto& attr : element.attributes) {
        if (attr.first == "x1") {
            x1 = stod(attr.second);
        }
        else if (attr.first == "y1") {
            y1 = stod(attr.second);
        }
        else if (attr.first == "x2") {
            x2 = stod(attr.second);
        }
        else if (attr.first == "y2") {
            y2 = stod(attr.second);
        }
        else if (attr.first == "stroke") {
            stroke = colorSVG(attr.second);
        }
        else if (attr.first == "stroke-opacity") {
            strokeOpacity = stod(attr.second);
        }
        else if (attr.first == "stroke-width") {
            strokeWidth = stod(attr.second);
        }
        else if (attr.first == "transform") {
            transform = attr.second;
        }
        else if (attr.first == "style") {
            style = attr.second;
        }
    }
}

void PolygonSVG::parseShapeSVG(const SVGElement& element) {
    for (const auto& attr : element.attributes) {
        if (attr.first == "points") {
            points = parsePointString(attr.second);
        }
        else if (attr.first == "fill") {
            fill = colorSVG(attr.second);
        }
        else if (attr.first == "fill-opacity") {
            fillOpacity = stod(attr.second);
        }
        else if (attr.first == "stroke") {
            stroke = colorSVG(attr.second);
        }
        else if (attr.first == "stroke-opacity") {
            strokeOpacity = stod(attr.second);
        }
        else if (attr.first == "stroke-width") {
            strokeWidth = stod(attr.second);
        }
        else if (attr.first == "transform") {
            transform = attr.second;
        }
        else if (attr.first == "style") {
            style = attr.second;
        }
    }
}
void PolylineSVG::parseShapeSVG(const SVGElement& element) {
    for (const auto& attr : element.attributes) {
        if (attr.first == "points") {
            points = parsePointString(attr.second);
        }
        else if (attr.first == "fill") {
            fill = colorSVG(attr.second);
        }
        else if (attr.first == "fill-opacity") {
            fillOpacity = stod(attr.second);
        }
        else if (attr.first == "stroke") {
            stroke = colorSVG(attr.second);
        }
        else if (attr.first == "stroke-opacity") {
            strokeOpacity = stod(attr.second);
        }
        else if (attr.first == "stroke-width") {
            strokeWidth = stod(attr.second);
        }
        else if (attr.first == "transform") {
            transform = attr.second;
        }
        else if (attr.first == "style") {
            style = attr.second;
        }
    }
}


void CircleSVG::drawCircleSVG(HDC hdc) {
    Graphics graphics(hdc);
    graphics.SetSmoothingMode(SmoothingModeAntiAlias);
    Pen pen(Color(strokeOpacity * 255, stroke.R, stroke.G, stroke.B), strokeWidth);
    RectF ellipseRect(cx - r, cy - r, r * 2, r * 2);
    graphics.DrawEllipse(&pen, ellipseRect);
    SolidBrush brush(Color(fillOpacity * 255, fill.R, fill.G, fill.B));
    graphics.FillEllipse(&brush, ellipseRect);
}

void EllipseSVG::drawEllipseSVG(HDC hdc) {
    Graphics graphics(hdc);
    graphics.SetSmoothingMode(SmoothingModeAntiAlias);
    Pen pen(Color(strokeOpacity * 255, stroke.R, stroke.G, stroke.B), strokeWidth);
    RectF ellipseRect(cx - rx, cy - ry, rx * 2, ry * 2);
    graphics.DrawEllipse(&pen, ellipseRect);
    SolidBrush brush(Color(fillOpacity * 255, fill.R, fill.G, fill.B));
    graphics.FillEllipse(&brush, ellipseRect);
}

void LineSVG::drawLineSVG(HDC hdc) {
    Graphics graphics(hdc);
    graphics.SetSmoothingMode(SmoothingModeAntiAlias);
    PointF point1(x1, y1);
    PointF point2(x2, y2);
    Pen pen(Color(strokeOpacity * 255, stroke.R, stroke.G, stroke.B), strokeWidth);
    graphics.DrawLine(&pen, point1, point2);
}

void PolygonSVG::drawPolygonSVG(HDC hdc) {
    Graphics graphics(hdc);
    graphics.SetSmoothingMode(SmoothingModeAntiAlias);
    Pen pen(Color(strokeOpacity * 255, stroke.R, stroke.G, stroke.B), strokeWidth);
    int size = points.size();
    PointF* point = new PointF[size];
    for (int i = 0; i < size; i++) {
        point[i].X = points[i].x;
        point[i].Y = points[i].y;
    }
    graphics.DrawPolygon(&pen, point, size);
    SolidBrush brush(Color(fillOpacity * 255, fill.R, fill.G, fill.B));
    graphics.FillPolygon(&brush, point, size);
}

void PolylineSVG::drawPolylineSVG(HDC hdc) {
    Graphics graphics(hdc);
    graphics.SetSmoothingMode(SmoothingModeAntiAlias);
    Pen pen(Color(strokeOpacity * 255, stroke.R, stroke.G, stroke.B), strokeWidth);
    int size = points.size();
    PointF* point = new PointF[size];
    for (int i = 0; i < size; i++) {
        point[i].X = points[i].x;
        point[i].Y = points[i].y;
    }
    graphics.DrawLines(&pen, point, size);
    SolidBrush brush(Color(fillOpacity * 255, fill.R, fill.G, fill.B));
    graphics.FillPolygon(&brush, point, size);
}

void RectSVG::drawRectSVG(HDC hdc) {
    Graphics graphics(hdc);
    graphics.SetSmoothingMode(SmoothingModeAntiAlias);
    Pen pen(Color(strokeOpacity * 255, stroke.R, stroke.G, stroke.B), strokeWidth);
    graphics.DrawRectangle(&pen, (int)x, (int)y, width, height);
    SolidBrush brush(Color(fillOpacity * 255, fill.R, fill.G, fill.B));
    graphics.FillRectangle(&brush, (int)x, (int)y, width, height);
}

void TextSVG::drawTextSVG(HDC hdc) {
    Graphics graphics(hdc);
    graphics.SetSmoothingMode(SmoothingModeAntiAlias);
    Pen pen(Color(strokeOpacity * 255, stroke.R, stroke.G, stroke.B), strokeWidth);
    std::wstring_convert<std::codecvt_utf8_utf16<wchar_t>> converter;
    std::wstring ws = converter.from_bytes(fontFamily);
    FontFamily fontFamily(ws.c_str());

    int font1 = 0;
    if (fontStyle == "bold" || fontStyle == "Bold") {
        font1 = 1;
    }
    else if (fontStyle == "italic" || fontStyle == "Italic") {
        font1 = 2;
    }

    Font font(&fontFamily, fontSize, font1, UnitPixel);
    PointF point(static_cast<float>(x) - fontSize, static_cast<float>(y) - fontSize);
    SolidBrush brush(Color(fillOpacity * 255, fill.R, fill.G, fill.B));
    wstring wstr = converter.from_bytes(textContent);
    graphics.DrawString(wstr.c_str(), -1, &font, point, &brush);
}