#include "TextSVG.h"
#include "SVGDemo.h"

void Text::readLine(const string& line) {
    string line1 = removeSpacesBetweenQuotes(line);
    istringstream iss(line1);
    string token;
    while (iss >> token) {
        size_t equalPos = token.find('=');
        if (equalPos != string::npos) {
            string key = token.substr(0, equalPos);
            string value = token.substr(equalPos + 2, token.size() - equalPos - 3);
            if (key == "x") {
                x = stod(value);
            }
            else if (key == "y") {
                y = stod(value);
            }
            else if (key == "fill") {
                fill = value;
            }
            else if (key == "font-size") {
                fontSize = stod(value);
            }
            else if (key == "font-family") {
                fontFamily = value;
            }
            else if (key == "font-weight") {
                fontWeight = stoi(value);
            }
            else if (key == "font-style") {
                fontStyle = value;
            }
            else if (key == "text-anchor") {
                textAnchor = value;
            }
            else if (key == "text-decoration") {
                textDecoration = value;
            }
            else if (key == "text-transform") {
                textTransform = value;
            }
        }
    }

    size_t openTagPos = line.find(">");
    size_t closeTagPos = line.find("</text>");
    if (openTagPos != string::npos && closeTagPos != string::npos) {
        textContent = line.substr(openTagPos + 1, closeTagPos - openTagPos - 1);
    }
}

void Text::drawText(HDC hdc) {
    Graphics graphics(hdc);
    Pen pen(Color(0, 0, 0, 0));
    std::wstring_convert<std::codecvt_utf8_utf16<wchar_t>> converter;
    std::wstring ws = converter.from_bytes(fontFamily);
    FontFamily fontFamily(ws.c_str());

    int font1 = 0;
    if (fontStyle == "bold" || fontStyle == "Bold") {
        font1 = 1;
    }
    else if (fontStyle == "italic" || fontStyle == "Italic") {
        font1 = 2;
    }

    Font font(&fontFamily, fontSize, font1, UnitPixel);
    PointF point(static_cast<float>(x), static_cast<float>(y));
    SolidBrush brush(Color(0, 0, 0, 0));
    graphics.DrawString(ws.c_str(), -1, &font, point, &brush);
}