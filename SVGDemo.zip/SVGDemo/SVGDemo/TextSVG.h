#pragma once
#include "FunctionRead.h"
#include "stdafx.h"
#include <locale>
#include <codecvt>

class Text {
private:
    string style = "";
    float fillOpacity = 0;
    string fill = "";
    int strokeWidth = 0;
    double x = 0;
    double y = 0;
    string transform = "";
    double fontSize = 0;
    int fontWeight = 0;
    string fontStyle = "";
    string fontFamily = "Times New Roman";
    string textAnchor = "";
    string textDecoration = "";
    string textTransform = "";
    string textContent = "";
public:
    void readLine(const string& line);
    void drawText(HDC);
};