#pragma once
#include "CircleSVG.h"
#include "EllipseSVG.h"
#include "FunTionRead.h"
#include "LineSVG.h"
#include "PolygonSVG.h"
#include "PolylineSVG.h"
#include "RectSVG.h"
#include "TextSVG.h"

